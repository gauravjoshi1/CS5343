The java file Quicksort.java has its own main methods which will be used to run test cases.
Compile the code on the terminal as follows:

javac Quicksort.java (generates class file for Quicksort)

Run the compiled class file:
java Quicksort