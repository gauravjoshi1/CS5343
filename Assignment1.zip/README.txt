Both the java files BubbleSort.java and TertiarySearch.java have their own main methods which will be used to run test cases.

Compile the code simply by importing to Intellij Project.